export class User {
    _id : string;
    firstName: string;
    lastName: string;
    emailId: string
    department: string;
    salary: string;
    gender: string;
    country: string;
}